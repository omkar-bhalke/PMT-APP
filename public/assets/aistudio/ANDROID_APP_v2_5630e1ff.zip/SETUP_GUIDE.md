# FinPulse SBI Automation: Poora Setup Guide (Hinglish)

Teen alag hisse hain. **Order yahi rakho: cPanel → Railway → Android.**

| Folder | Kahan chalta hai | Kaam |
|---|---|---|
| `CPANEL_BACKEND/` | Tumhara hosting (`radhewins.buzz`) + MySQL | Users, login, balance, transactions, pending queue, settings, logs (permanent data) |
| `RAILWAY_BACKEND/` | Railway (24x7 Node.js) | WhatsApp session, SBI ko "Hi" bhejna, statement parse, scheduler |
| `ANDROID_APP/` | Tumhara phone | UI, WhatsApp linking screen, notifications, transaction form |

## Teeno ek dusre se kaise jude hain

```
Android ──(login token, HTTPS)──► cPanel  https://radhewins.buzz/api/...
Android ──(same login token)────► Railway https://xxxx.up.railway.app/api/...
Railway ──(HMAC signed, SERVICE_SECRET)──► cPanel /api/internal/...
cPanel  ──(sirf RAILWAY_PUBLIC_URL batata hai)──► Android ko Railway ka address milta hai
```

Sirf **3 cheezein** match karni hain:

| # | Cheez | Kahan likhni hai |
|---|---|---|
| 1 | `SERVICE_SECRET` (same value dono jagah) | cPanel `finpulse_config.php` **aur** Railway Variables |
| 2 | cPanel ka URL | Railway variable `CPANEL_API_URL` **aur** Android `CPANEL_BASE_URL` |
| 3 | Railway ka URL | cPanel `finpulse_config.php` ka `RAILWAY_PUBLIC_URL` |

Android app ko Railway ka URL **khud** `GET /api/app-config` se mil jata hai (cPanel se). Android mein koi password ya secret nahi hota.

---

## PART 1: cPanel (pehle yeh)

### 1.1 MySQL database banao
1. cPanel → **MySQL® Databases**.
2. *Create New Database*: naam e.g. `finpulse` (final naam `radhewin_finpulse` jaisa ban jayega, note kar lo).
3. *MySQL Users → Add New User*: e.g. `fpuser`, **strong password** (note kar lo).
4. *Add User To Database* → user + database select → **ALL PRIVILEGES** → Make Changes.

### 1.2 SQL import karo
1. cPanel → **phpMyAdmin** → left side mein apna database select karo.
2. **Import** tab → `CPANEL_BACKEND/database.sql` choose → Go.
3. Agar tumne **pehle purana (v2) schema import kar rakha hai**, to `database.sql` ki jagah `CPANEL_BACKEND/upgrade_from_v2.sql` **ek baar** chalao (SQL tab mein paste).
4. `database.sql` dobara chalana safe hai (koi `DROP` nahi, data nahi udta).

### 1.3 Files upload karo
1. cPanel → **File Manager** → `public_html` (ya jis folder mein domain point karta hai).
2. `CPANEL_BACKEND` ke **andar ki sab files/folders** upload karo (`index.php`, `.htaccess`, `config/`, `controllers/`, `helpers/`, `middleware/`). Hidden files dikhane ke liye File Manager → Settings → *Show Hidden Files*, taaki `.htaccess` dikhe.
3. `database.sql`, `upgrade_from_v2.sql`, `*.md` server par upload karna zaroori nahi.
4. Agar domain par pehle se koi website hai, `public_html/finpulse/` jaisa subfolder bana ke wahan upload karo. Tab tumhara API URL `https://radhewins.buzz/finpulse` hoga (aage `CPANEL_API_URL` aur Android `CPANEL_BASE_URL` mein yahi likhna).

### 1.4 Private config file banao (sabse zaroori)
1. `config/config.sample.php` ko copy karke **`/home/<cpanel-username>/finpulse_config.php`** naam se rakho. Yeh `public_html` ke **bahar** hona chahiye.
2. Har `CHANGE_ME` badlo:
   - `DB_NAME`, `DB_USER`, `DB_PASS`: step 1.1 wale.
   - `JWT_SECRET_KEY`, `AES_ENCRYPTION_KEY`, `SERVICE_SECRET`: teen **alag** random strings, har ek kam se kam 32 character. Apne PC par terminal mein `openssl rand -hex 32` teen baar chalao.
   - `RAILWAY_PUBLIC_URL`: abhi khali chhod do, Part 2 ke baad bharoge.
3. **`SERVICE_SECRET` ki value copy karke rakho**, Railway mein wahi daalni hai.

### 1.5 Check karo
Browser mein kholo: `https://radhewins.buzz/api/health`
Aisa JSON aana chahiye: `{"success":true,"message":"FinPulse backend is online." ...}`

| Dikhe | Matlab |
|---|---|
| `NOT_CONFIGURED` | `finpulse_config.php` nahi mili ya `CHANGE_ME` bacha hai |
| `DB_UNAVAILABLE` | DB naam/user/password galat |
| 404 | `.htaccess` upload nahi hui ya mod_rewrite band hai (hosting support se poocho) |

---

## PART 2: Railway

### 2.1 Code Railway par daalo
Option A (aasaan): `RAILWAY_BACKEND` ke andar ki files ek **naye private GitHub repo** mein push karo → Railway → **New Project → Deploy from GitHub repo**.
Option B: Railway CLI: `cd RAILWAY_BACKEND && railway login && railway init && railway up`.
`Dockerfile` aur `railway.json` pehle se hain, Railway khud pehchan leta hai.

### 2.2 Environment variables
Service → **Variables** → yeh daalo:

| Variable | Value | Zaroori? |
|---|---|---|
| `CPANEL_API_URL` | `https://radhewins.buzz` (subfolder ho to `https://radhewins.buzz/finpulse`), **end mein `/` nahi** | Haan |
| `SERVICE_SECRET` | Step 1.4 wali **same** value | Haan |
| `DATA_DIR` | `/data` | Haan |
| `SBI_TARGET_NUMBER` | `919022690226` (sirf fallback; asli target cPanel DB mein hai) | Nahi |
| `SCHEDULER_TICK_MS`, `MAX_CONCURRENT_CYCLES`, `CYCLE_TIMEOUT_MS`, `MENU_TIMEOUT_MS`, `RUN_NOW_MIN_GAP_MS`, `LOG_LEVEL` | defaults theek hain | Nahi |

`PORT` Railway khud set karta hai. Variable na ho to app start hi nahi hoga aur logs mein saaf likha aayega kaun sa missing hai (koi hardcoded secret nahi hai).

### 2.3 Persistent Volume (bahut zaroori: iske bina WhatsApp bar bar disconnect hota hai)
Bina volume ke Railway har deploy/restart par files delete kar deta hai, to WhatsApp session ud jata hai aur dobara link karna padta hai. **Naye code mein agar volume nahi hai to app link karne hi nahi dega** aur saaf message dikhayega.

Volume ka option service ke andar nahi, **project ke canvas** par hota hai (jahan service ka box dikhta hai):
1. Railway → apna **Project** kholo (service ke andar nahi, project ka main screen jahan box dikhta hai).
2. Upar right mein **+ Create** (kabhi **+ New**) dabao → list mein **Volume** chuno.
   - Option na dikhe to browser menu (⋮) → **Desktop site** ON karke dobara dekho.
3. Poochhe to **service chuno** (apni `RAILWAY_BACKEND` wali) aur **Mount path: `/data`** likho → Create.
4. Service redeploy hogi (normal).
5. Check: service → **Variables** mein Railway ka apna variable `RAILWAY_VOLUME_MOUNT_PATH` dikhna chahiye (value `/data`). Aur `https://<railway-url>/health` mein `"persistentStorage":true` aana chahiye.

Alternative (laptop se): `railway volume add --mount-path /data` (Railway CLI).
Sirf test ke liye (volume ke bina, har restart par link udega): Variable `ALLOW_EPHEMERAL_STORAGE=true`.

### 2.4 Public domain
Service → **Settings → Networking → Generate Domain** → URL copy karo (e.g. `https://finpulse-worker-production.up.railway.app`).
Browser mein `https://<tumhara-url>/health` kholo → `{"ok":true,...}` aana chahiye.

### 2.5 Railway ka URL cPanel ko batao
`/home/<user>/finpulse_config.php` mein:
```php
define('RAILWAY_PUBLIC_URL', 'https://finpulse-worker-production.up.railway.app');
```
Check: `https://radhewins.buzz/api/app-config` mein yahi URL dikhna chahiye.

### 2.6 Railway ↔ cPanel connection test
Railway **Deploy Logs** mein yeh line aani chahiye: `listening on :PORT ... cpanel=https://radhewins.buzz`. Phir `restored 0 WhatsApp session(s)` (abhi koi linked nahi).
Agar `SERVICE_AUTH_INVALID` / `Invalid service signature` dikhe to dono jagah `SERVICE_SECRET` alag hai. `Service request expired` dikhe to server ki clock galat hai.

---

## PART 3: Android app

### 3.1 Build
1. **Android Studio** (Koala ya naya, JDK 17) mein `ANDROID_APP` folder open karo → Gradle Sync.
2. `app/build.gradle.kts` mein `CPANEL_BASE_URL` default `https://radhewins.buzz/` hai. Subfolder use kiya ho to badlo (end mein `/` rakho).
3. Phone USB debugging ON karke **Run ▶**. (Debug build ke liye keystore ki zaroorat nahi.)
   > Note: yeh project is chat mein compile nahi ho saka (Android SDK nahi tha). Pehli baar build par chhoti compile errors aa sakti hain. Dekho `STATUS.md`. Error ka text bhej doge to theek kar dunga.

### 3.2 Account banao aur permissions do
1. App kholo → **Register** (yeh cPanel par per-user account banata hai) → onboarding.
2. Android 13+ par **Notifications allow** karo (zaroori, nahi to reminder nahi dikhega).
3. Phone ki **Battery settings** mein FinPulse ko *Unrestricted* karo (Xiaomi/Oppo/Vivo par "Autostart" bhi ON), warna background sync late ho sakta hai.

### 3.3 WhatsApp link (app ke andar)
1. **Settings → Statement Automation → Link now** (ya WhatsApp Integration → pehla tab).
2. Pehle ek **orange warning** dikhti hai: yeh *unofficial* Baileys client hai, official WhatsApp/SBI API nahi, account restriction ka risk hai. Padh lo.
3. **QR**: "Show QR code" dabao → jis phone mein WhatsApp hai uske **Settings → Linked devices → Link a device** se scan karo.
4. **Same phone par ho to Pairing code**: apna number country code ke saath (e.g. `919876543210`) → "Get pairing code" → WhatsApp → Linked devices → Link a device → *Link with phone number instead* → code type karo.
5. Status **Connected** (green) ho jayega. Reconnecting = peela, Disconnected = laal.
6. Disconnect karna ho to wahin **Disconnect WhatsApp** (server se session delete ho jata hai).

### 3.4 Automation chalu karo
**Settings → Statement Automation** → switch ON, interval chuno (15 min / 30 min / 1 hr ... ya custom; minimum 5 min, **30+ min recommended**).
Pehla fetch kuch seconds mein chalta hai. **Fetch now** se manual bhi chala sakte ho.

---

## PART 4: Poora flow asli mein test karo

1. **Health:** `…/api/health` (cPanel) aur `…/health` (Railway) dono OK.
2. **Link:** app mein WhatsApp **Connected** dikhe. phpMyAdmin → `whatsapp_sessions` mein tumhari row `CONNECTED`.
3. **Fetch:** Automation switch ON → 10-60 second mein **Execution history** mein "Balance … first statement stored as baseline" dikhe. Balance screen par tumhara **asli** SBI balance dikhe.
   - Pehla statement sirf *starting point* banta hai, purane 5 entries ke sawal nahi aate (setting se badal sakte ho).
4. **Naya transaction:** SBI se koi chhota asli transaction karo (ya aane do) → agle fetch ke baad phone par notification: *"New transaction detected. What was this ₹X spent on?"*.
5. **Jawab:** notification tap → form (sahi amount/date ke saath) → category + purpose → Save. phpMyAdmin → `transactions` mein row (`source = SBI_WHATSAPP`) aur `pending_transactions.status = CONFIRMED`.
6. **Offline test:** phone Airplane mode → Railway tab bhi fetch karta rahega → 2-3 transactions queue → phone wapas online → kuch minute mein (ya app kholne par turant) sab ek-ek karke poochhe jayenge.
7. **Restart test:** Railway → Deployments → **Redeploy**. WhatsApp **Connected** hi rehna chahiye (volume ki wajah se), aur schedule chalta rahe.

### Agar SBI se jawab nahi aata (pehli live run mein hona mumkin hai)
SBI ke bot ka menu button/list/text kis shape mein aata hai, yeh mujhe yahan live check karne ka mauka nahi mila. Isliye code teen tareeke try karta hai (list/button click, phir plain text "Get Mini Statement"). Agar history mein `SBI did not respond` ya `no menu` aaye to **Execution history ki wo line** (jisme `recv:<shape>` events hote hain) bhejo, main parser/click ko us shape ke hisaab se theek kar dunga.

---

## Troubleshooting

| Problem | Karan / Ilaaj |
|---|---|
| App mein "Railway URL is not configured" | cPanel config mein `RAILWAY_PUBLIC_URL` bharo; ya Link screen → Advanced mein URL daalo |
| Link karte hi turant Disconnected | Railway logs dekho; QR 3 minute tak refresh hota rehta hai. Link Window `LINK_WINDOW_MS` |
| Redeploy ke baad / bar bar dobara link maangta hai | Volume `/data` attach nahi hua (2.3). `/health` mein `persistentStorage:true` hona chahiye |
| Link hote hi turant 401 / 'logged out' | Phone ke WhatsApp → Linked devices mein session dikhta hai? Ek hi session ko do jagah (do Railway deployments) mat chalao |
| App mein 'Notifications: OFF' | Automation screen → Open settings; phir 'Send test notification' dabao |
| "Paused: WhatsApp disconnected" | Phone se WhatsApp → Linked devices mein session hata diya gaya. Dobara link karo, automation khud resume hoga |
| Notification nahi aa rahi | Notification permission, battery *Unrestricted*, app ek baar khol lo (WorkManager schedule hota hai) |
| `LOCK_LOST` logs | Cycle timeout se lamba chala; ignore, agla cycle theek chalega |
| 401 "Session expired" | Dubara login karo |

## Security ke liye yaad rakho
- `finpulse_config.php` kabhi public_html ya Git mein mat rakho.
- `SERVICE_SECRET` kisi ko mat dena. Leak ho to dono jagah badal do.
- Har user ka WhatsApp session alag folder `/data/sessions/<userId>` mein, permission 0700; koi API credentials wapas nahi bhejti.
- SBI ka target number (`919022690226`) user app se badal nahi sakta, sirf cPanel DB mein admin badal sakta hai (`automation_settings.sbi_target_phone`).
