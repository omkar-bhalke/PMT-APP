# STATUS: Kya bana, kya test hua, kya nahi (sach-sach)

Test environment (is chat mein): PHP 8.3.6 + MariaDB 10.11 (asli), Node 22, Baileys 6.7.24 install hua.
Sirf WhatsApp socket ek **test double** hai (`RAILWAY_BACKEND/test/helpers/fakeWhatsapp.js`, sirf `test/` mein, production code mein nahi).

## A. Implemented AUR automatically tested (29/29 pass: `npm test`)
| Feature | Kaise verify hua |
|---|---|
| Statement parser (date/time, masked a/c, balance, CR/DR, amounts with commas, 2 identical lines) | 10 unit tests; fake data kabhi invent nahi karta (missing => error) |
| "please wait…" message final statement nahi maana jata | unit + integration |
| Naye entries ki pehchaan (previous statement se alignment), balance diff explained | 433.77 → 333.77: 1 entry, diff −100, koi extra txn nahi |
| Pehla statement = baseline, flood nahi | integration |
| Duplicate statement → kuch naya nahi; 2 identical naye lines dono rakhe gaye | integration |
| 20 DR / 41 DR / 500 CR offline queue → baad mein sab pending | integration |
| Offline answers idempotent sync (retry par duplicate nahi), purpose mandatory, category auto-create | integration (real PHP + MySQL) |
| `accounts.current_balance` bank balance hi rehta hai (double adjust nahi) | integration |
| Per-user isolation (dusra user pending dekh/confirm/log nahi kar sakta) | integration |
| Token ke bina/galat token 401; unsigned/forged/stale service calls 401 | integration |
| SBI chup → NO_RESPONSE, retry, lock release (RUNNING mein atakta nahi) | integration |
| Format badla → PARSE_ERROR, balance untouched | integration |
| cPanel/DB fail → volume outbox mein queue → ek baar deliver | integration |
| WhatsApp drop → PAUSED_DISCONNECTED + error, reconnect par resume | integration |
| Do cycles ek saath nahi (DB lock, 3 parallel claims → 1 winner) | integration |
| Railway restart par schedule + session bache (DB job state + volume) | integration (naya process, wahi dataDir) |
| Disconnect session folder delete karta hai | integration |
| DB band hone par API generic 503 (credentials leak nahi) | manual curl |
| `database.sql` dobara import safe; `upgrade_from_v2.sql` purane data par chala | manual |

## B. Implemented, lekin **live test NAHI hua** (mere paas asli WhatsApp/SBI/Android device nahi tha)
| Feature | Risk |
|---|---|
| Asli WhatsApp QR / pairing code linking (Baileys) | Code real Baileys API use karta hai (exports verify kiye), par live link nahi hua |
| SBI bot ke saath asli conversation (menu "Get Mini Statement📑" click) | SBI ka menu shape unknown. Click (list/button/native) + text fallback. Pehli run mein tweak lag sakta hai |
| LID (hidden number) se aaya SBI reply | First-contact trust + learned LID; live check baaki |
| **Poora Android app** | **Compile nahi kiya** (Android SDK/Maven yahan nahi). Kotlin parser se sirf syntax check hua (0 syntax/redeclaration error), types/Compose build Android Studio mein hi confirm honge |
| Notifications, WorkManager timing, notification tap → form, snooze button | Device par check nahi |
| Android offline answer queue + local ledger mirror | Device par check nahi |
| cPanel asli Apache/LiteSpeed `.htaccess` rewrite | Maine PHP built-in server + wahi routing logic use kiya |
| Railway Docker build/deploy, volume | Build chalaya nahi |

**Isliye "poora real flow (WhatsApp → SBI → notification → DB)" end-to-end abhi verified NAHI hai.** Server-side ke 80% hisse (parser→DB→pending→confirm) asli PHP+MySQL par verified hain; WhatsApp-leg aur Android-leg tumhare device par pehli baar chalenge. `SETUP_GUIDE.md` Part 4 exactly wahi test hai.

## C. Jaan-boojh kar / abhi nahi
- **Instant push (FCM) nahi**: background sync WorkManager se hai (har ~15 min, internet milte hi turant try). App khula ho to har 45 sec. Instant ke liye FCM baad mein jod sakte hain.
- **Overlay/floating popup nahi** (zaroori nahi tha) aur **Accessibility ka koi use nahi** is feature mein.
- Pehla statement entries import nahi karta (default), setting se ON ho sakta hai.
- SBI mini statement sirf last ~5 entries dikhata hai. Do fetch ke beech 5 se zyada transactions hon to purane miss ho sakte hain; system `gap/discrepancy` warning log karta hai, chhupata nahi.
- Android par token DataStore mein plain (Keystore-encrypted nahi). `allowBackup=false` kiya hai.
- cPanel login par brute-force rate limiting nahi.
- WhatsApp credentials Railway volume par files mein (0700); extra encryption-at-rest nahi.
- Multiple SBI accounts per user: har account ka alag baseline chalta hai, par UI sirf latest dikhata hai.

## D. Purane project mein kya theek kiya (bugs)
1. `@whiskeysockets/baileys ^6.7.18` → deprecated/vulnerable 6.17.16 resolve ho sakta tha. Ab exact **6.7.24**.
2. Railway↔cPanel routes/headers match hi nahi karte the (integration kaam nahi karta). Ab signed `/api/internal/*`.
3. Railway `authGuard` koi bhi Bearer ya (password na ho to) sab accept karta tha. Ab har request cPanel se verify.
4. Single-user (`DEFAULT_USER_ID`) tha. Ab per-user session/scheduler.
5. cPanel `AUTOMATION_API_KEY` "pehle user" ko impersonate karta tha. Hataya.
6. Hardcoded secrets/default password. Ab private config + startup par reject.
7. Parser fake `xxx188`/aaj ki date bana deta tha. Ab error deta hai.
8. Same-looking 2 transactions ka hash same → ek drop. Ab sequence alignment.
9. Timeout ke baad scheduler RUNNING mein atak jata tha. Ab DB lock expiry + complete.
10. `database.sql` mein `DROP TABLE` (re-import par data delete). Hataya.
11. Notification sirf app khula ho tab. Ab WorkManager.
12. Pending/Automation screens NavHost mein register hi nahi the. Ab wired.
13. Debug HTTP logger tokens/bank data logcat mein likhta tha. Ab debug-only, headers/body nahi.
14. cPanel 500 errors exception text leak karte the. Ab generic.
15. Categories duplicate dikhti thi. Fix.
16. Debug build `debug.keystore` ke bina fail hota. Fix.

## E. Purane features jo hataye / badle (karan ke saath)
- `RAILWAY_BACKEND/public/` dashboard + purana `server.js`: single-user, unauthenticated tha.
- Android `PendingTransactionsDialog`, purani Railway-URL wali linking tab, purana AutomationSettings: naye per-user API ke saath incompatible, replace kiye.
- Pending "dismiss" button UI se hataya (spec: pending kabhi skip/delete nahi). API endpoint rakha hai.
- **Meta Cloud API tab, App Restrictions + Accessibility service, baaki poora expense tracker: jaise the waise.**


## F. v2 update (tumhare log + code ke baad)
- **Build error ki jad:** original project mein `CloudWhatsAppDto` define hi nahi tha (mujhse miss hua, kyunki mera check sirf syntax tak tha). Tumhara fix sahi. `RealBalanceResponse.success` ka default `true` bhi sahi fix tha (mera bug).
- **WhatsApp bar bar disconnect:** (1) Railway par Volume nahi tha, to restart par session delete. (2) Log mein "Bad MAC" ka loop: dusre chats ke messages decrypt ho rahe the. Ab sirf SBI ki chat decrypt hoti hai, baaki acknowledge hokar ignore. (3) `start()` race se do socket ban sakte the: ab single-flight. (4) 500 par turant delete nahi, pehle retry. (5) Volume na ho to link block + saaf message.
- **Notification:** permission/notification band hone par bhi item "notified" mark ho jata tha (fix), alag status-bar icon, "Send test notification" button, app khula ho to 30 sec mein popup (Later = pending rehta hai).
- Tests: 35/35 pass (6 naye: single-flight, SBI-only filter, 401/500 handling, volume detection).
- Abhi bhi live-test baaki: asli WhatsApp link stability, SBI menu click, Android device par notification.
